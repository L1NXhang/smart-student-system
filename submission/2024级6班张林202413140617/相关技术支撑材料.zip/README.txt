# 智慧学工系统 - 相关技术支撑材料

## 包含内容

1. 数据库设计方案与PRD.md
   - 完整28张数据表结构设计
   - 各模块功能需求说明
   - 系统架构与技术栈说明
   - UI/UX设计规范

2. API接口文档.md
   - 全部RESTful API接口定义
   - 请求/响应格式说明
   - WebSocket实时通信协议
   - 错误码对照表
   - 文件上传规范

## 技术栈

- 前端: Vue 3 + Vite + Element Plus + GSAP + Pinia
- 后端: Node.js + Express + Sequelize + MySQL
- 实时通信: Socket.io
- 认证: JWT
- 部署: 腾讯云 + Docker + Nginx

## 在线访问
http://124.223.0.187/smart/
